export interface Employee
{
    id : number ; 
    firstName : string ;
    lastName : string ;
    salary : number ;
    gender : string ; 
}